package org.brsu.exercise2.application;

import org.brsu.exercise2.gui.MainFrame;

public class ColorTester {

	public static void main(String[] args) {
		new MainFrame();
	}
}
